fx_version 'bodacious'
games { 'gta5' }


replace_level_meta 'gta5'

files {
    'gta5.meta',
    'junctions.xml'
}
